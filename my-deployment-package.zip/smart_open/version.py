__version__ = '4.2.0'


if __name__ == '__main__':
    print(__version__)
